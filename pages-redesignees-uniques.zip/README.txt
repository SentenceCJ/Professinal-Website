DOSSIER DES PAGES REDESIGNÉES

Chaque page possède maintenant une structure visuelle différente, tout en partageant un seul fichier CSS :
assets/css/pages.css

Pages incluses :
- integrations-web.html
- seo-local-lyon.html
- refonte-site-internet.html
- optimisation-mobile-performance.html
- maintenance-site-web.html
- deroulement-projet.html
- pourquoi-me-choisir.html

Les pages conservent les métadonnées SEO, la navigation et le footer d'origine.
Les photographies sont chargées depuis Unsplash via URL.
Le script existant assets/js/script.js est conservé comme référence : gardez votre script actuel dans votre projet.
